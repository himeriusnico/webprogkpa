<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Week 7 - Latihan Home</title>
</head>

<body>
  <?php
  echo "Welcome" . $_COOKIE['nrp'];
  ?>

  <a href="latihan-logout.php">logout</a>
</body>

</html>