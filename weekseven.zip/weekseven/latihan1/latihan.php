<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Week 7 - Latihan</title>
</head>

<body>
  <form method="POST" action="latihan-proses.php">
    <input type="text" name="user" placeholder="Username"><br>
    <input type="password" name="pass" placeholder="Password"><br>
    <input type="submit" name="submit" value="Login">

  </form>
</body>

</html>