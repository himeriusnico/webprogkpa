<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style type = "text/css">
        .makan:link{
            color :blue;
            text-decoration: none;
        }
        .makan:hover{
            color :red;
            text-decoration: underline;
        }
        .minum:link{
            color : red;
            font-weight: bold;
        }
        .minum:hover{
            color: blue;
            text-decoration: none;
            font-weight: normal;
        }
    </style>
</head>
<body>
    <p>Makanan</p>
    <ul>
        <li><a class = "makan" href="burger.php">Burger</a></li>
        <li><a class = "makan" href ="pizza.php">Pizza</li>
    </ul>
    <p>Minuman</p>
    <ul>
        <li><a class= "minum" href = "air.php">Air putih</a><li>
    </ul>

    <?php
    $num = mt_rand(1,6);
    echo "<img src='img/$num.jpg'>";

    // or
    // $src = "";

    // if ($num == 1){
    //     $src = "img/1.jpg";
    // }
    // else if ($num == 2){
    //     $src = "img/2.jpg";
    // }
    // else if ($num == 3){
    //     $src = "img/3.jpg";
    // }
    // else if ($num == 4){
    //     $src = "img/4.jpg";
    // }
    // else if ($num == 5){
    //     $src = "img/5.jpg";
    // }

    ?>
</body>
</html>