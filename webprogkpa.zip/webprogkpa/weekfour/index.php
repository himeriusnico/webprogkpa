<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WeekFour-image dan link</title>
    <style type ="text/css">
        /* img{
            width : 100px;
            height : 200px
        } */
        a:link{ color: red;}
        a:hover{ color: green;}
        /* a:visited{ color: black;} */
        a:active{ color: yellow;}
    </style>
    <link rel = "stylesheet" href = "index.css">
</head>
<body>
    <img class = "image" src ="img/mercedes.jpg" alt="Gambar">
    <p>Link Bookmark klik <a href="#sini">sini</a>

    <p>link ke file ubaya klik <a href = "https://www.ubaya.ac.id">sini</a></p>

    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p id="sini">Ke sini</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
    <p>..</p>
</body>
</html>