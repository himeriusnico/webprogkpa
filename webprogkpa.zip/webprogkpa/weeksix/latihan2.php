<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>week6 - latihan2</title>
</head>

<body>
  <form method="POST" action="latihan2-proses.php">
    <input type="checkbox" name="hero[]" value="Batman">Batman <br>
    <input type="checkbox" name="hero[]" value="Superman">Superman <br>
    <input type="checkbox" name="hero[]" value="Spiderman">Spiderman <br>
    <input type="checkbox" name="hero[]" value="Hulk">Hulk <br>
    <input type="submit" name="submit" value="Proses">
  </form>
</body>

</html>