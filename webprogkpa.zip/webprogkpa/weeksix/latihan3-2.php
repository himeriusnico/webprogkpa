<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <form method="post" action="latihan3-3.php">
    <?php
    $jumlah = $_POST["jumlah"];
    for ($i = 1; $i <= $jumlah; $i++) {
      echo "Warna Kotak $i";
      echo "<input type =\"text\" name =\"warna[]\"><br>";
    }
    ?>
    <input type="hidden" name="jumlah" value="<?= $jumlah ?>">
    <input type="submit" name="submit" value="Proses">
  </form>

</body>

</html>