<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>latihan3.1 - week6</title>
</head>

<body>
  <form method="POST" action="latihan3-2.php">
    <?php

    ?>
  </form>
</body>

</html>