<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Latihan3-3 - week6</title>
</head>

<body>
  <?php
  $warna = $_POST['warna'];

  foreach ($warna as $key => $value) {
    echo "<div style=\"background-color: $value;\">";
    echo "$value <br>";
    echo "</div>";
  }
  ?>
  <!-- <div style="background-color: #AAA000;">
    AAA000
  </div> -->
</body>

</html>