<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <?php
  $mk = array(
    array("status" => "wajib", "kode" => "1604A011", "nama" => "Alpro"),
    array("status" => "wajib", "kode" => "1604A021", "nama" => "OOP"),
    array("status" => "pilihan", "kode" => "1604A19A", "nama" => "Special Topic in AI"),
    array("status" => "pilihan", "kode" => "1604A19B", "nama" => "Special Topic in DS"),
    array("status" => "pilihan", "kode" => "1604A19C", "nama" => "Modelling and Simulation")
  );

  echo $mk[0]["nama"];

  echo "<ol>";
  foreach ($mk as $key => $value) {
    // $kode = $mk[$key]["kode"];
    // $nama = $mk[$key]["nama"];
    // $status = $mk[$key]["status"];
    //namun karena sudah pake foreach jadi lebih baik

    $kode = $value["kode"];  //karena hasilnya sama aja
    $nama = $value["nama"];
    $status = $value["status"];

    echo "<li>$kode - $nama ($status)</li>";
  }
  ?>

  <?php
  $nilai = array(
    // array("nisbi" => "A", "min" => 81, "max" => 100),
    // array("nisbi" => "AB", "min" => 73, "max" => 80),
    // array("nisbi" => "B", "min" => 66, "max" => 72),
    // array("nisbi" => "BC", "min" => 60, "max" => 65),
    // array("nisbi" => "C", "min" => 55, "max" => 59),
    // array("nisbi" => "D", "min" => 40, "max" => 54),
    // array("nisbi" => "E", "min" => 0, "max" => 39)

    "A" => array("min" => 81, "max" => 100),
    "AB" => array("min" => 73, "max" => 80),
    "B" => array("min" => 66, "max" => 72),
    "BC" => array("min" => 60, "max" => 65),
    "C" => array("min" => 55, "max" => 59),
    "D" => array("min" => 40, "max" => 54),
    "D" => array("min" => 0, "max" => 39),
    
  )
  ?>
</body>

</html>