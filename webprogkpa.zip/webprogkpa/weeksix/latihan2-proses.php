<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>week6 - proses</title>
</head>

<body>
  <?php
  $hero = $_POST['hero'];
  foreach ($hero as $key => $value) {
    echo "$value <br>";
  }
  ?>
</body>

</html>