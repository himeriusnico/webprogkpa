<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Week 7 - latihan 2-1</title>
</head>

<body>
  <form method="POST" action="latihan2-2.php">
    <input type="text" name="buah" placeholder="Nama Buah"><br>
    <input type="submit" name="submit" value="Send">

  </form>
</body>

</html>