<?php

$name = "Nico Isao";
$email = "himeriusnico03@gmail.com";
$phone = "+6281326489410";
$address = "Jl. Tenggilis mejoyo rungkut gg. III";

$education = array(
    array(
        "degree" => "Informatika - Network & CyberSecurity",
        "institution" => "Universitas Surabaya",
        "year" => "2022- Sekarang"
    )
);

$skills = array(
    "PHP",
    "HTML",
    "CSS"
);

?>
