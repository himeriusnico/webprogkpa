<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style type = "text/css">
        .warna-merah { color:red; }
        .warna-biru { color:blue;}
        .huruf-tebal { font-weight: bold; }
    </style>
</head>
<body>
    <?php
    $n = 5;

    for($i = 1; $i<=$n;$i++)
    {
        if ($i % 2 == 0){
            $warna = "warna-merah";
        }
        else{
            $warna = "warna-biru";
        }

        $tebal = ($i==1 || $i == $n)  ? "huruf-tebal" : "";

        //echo "<p>paragraph ke-". $i . "</p>";
        echo "<p id = \"par$i\" class =\"$warna $tebal\">paragraph ke-". $i . "</p>";
    }
    ?>

    <?php
    $birthdate = 12;
    for($i= $birthdate; $i<=100; $i++){
        if ($i % $birthdate == 0){
            echo "<ul><li>$i <br></li></ul>";
        }
    }

    ?>
    <!-- <p id = "par1" class = "warna-merah">Paragraph ke-1</p> -->
</body>
</html>