<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style type ="text/css"> //inline css
            .latar-cerah {background: #fdABAB;}
            .latar-gelap {background: #98A9B0;}
    </style>
</head>
    <?php
        $angka = mt_rand(1,10);

        if ($angka % 2 == 0){
            echo '<body class="latar-cerah">';
        }
        else{
            echo '<body class="latar-gelap">';
        }
    ?>
<body>
    <p>Angka yang terpilih: <?php echo $angka; ?></p>

    //kalo hanya untuk buka echo gini aja
    <//?=$angka;?>
</body>
</html>